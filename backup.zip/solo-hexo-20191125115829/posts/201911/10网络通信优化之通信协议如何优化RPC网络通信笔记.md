title: 《10:网络通信优化之通信协议：如何优化RPC网络通信》笔记
date: '2019-11-20 19:22:14'
updated: '2019-11-20 19:59:32'
tags: [java性能调优实战]
permalink: /articles/2019/11/20/1574248934111.html
---
![](https://img.hacpai.com/bing/20190322.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

[原文](https://time.geekbang.org/column/article/100355)
# 架构演变史
![e43a8f81d76927948a73a9977643daa5.jpg](https://img.hacpai.com/file/2019/11/e43a8f81d76927948a73a9977643daa5-7e5579fb.jpg)

## 微服务
微服务的核心是**远程通信和服务治理**。远程通信提供了服务之间通信的桥梁，服务质量提供了服务的后勤保障。在满足一定的服务治理需求的前提下，对远程通信的性能需求是技术选型的主要影响因素。

### SpringCloud
SpringCloud是基于Feign组件实现的RPC通信(基于Http+Json序列化实现)。
### Dubbo
Dubbo是基于SPI扩展了很多RPC通信框架，包括RMI,Dubbo,Hessian等RPC通信框架(默认是Dubbo+Hessian序列化)。



## 什么是RPC通信
RPC(Remote Process Call),即远程服务调用，是通过网络请求远程计算机服务的通信技术。

## RMI
RMI(Remote Method Invocation)是JDK中最先实现了RPC通信的框架之一，RMI的实现对建立分布式Java应用程序至关重要，很多开源的RPC通信框架也是基于RMI实现原理设计出来的。包括Dubbo框架中也接入了RMI框架。RMI实现了一台虚拟机对远程方法的调用如同对本地方法的调用一样。

### RMI实现原理
![1113e44dd62591ce68961e017c11ed4f.jpg](https://img.hacpai.com/file/2019/11/1113e44dd62591ce68961e017c11ed4f-f8563d94.jpg)

### RMI在高并发下的性能瓶颈
* Java默认序列化
* TCP短连接
* 阻塞式网络I/O

## RPC通信优化路径
* 选择合适的通信协议
* 使用单一长连接
* 优化socket通信
* 量身定做报文格式
* 编码、解码
* 调整linux的TCP参数设置选项
![9eb01fe017b267367b11170a864bd0bc.jpg](https://img.hacpai.com/file/2019/11/9eb01fe017b267367b11170a864bd0bc-b71a555a.jpg)


