title: centos6.9服务器调用第三方接口缓慢问题排查
date: '2019-10-09 14:51:14'
updated: '2019-10-09 21:36:34'
tags: [centos]
permalink: /articles/2019/10/09/1570603874533.html
---
![](https://img.hacpai.com/bing/20171110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前提 
内网测试反应很快，但是项目部署到外网后发现调用短信接口、阿里云视频播放凭证接口缓慢，大概平均得需要5秒钟才会响应，内网却没有问题。

## 解决思路
* 首先排除是第三方接口响应慢
* 通过curl 查询是哪一步操作反应慢
```
curl -w "%{time_namelookup}\n%{time_connect}\n%{time_pretransfer}\n%{time_starttransfer}\n%{time_total}" -o /dev/null -s -L https://www.baidu.com
```
**参数含义**
* time_namelookup： DNS解析时间  
    
* time_connect：TCP 连接建立的时间，就是三次握手的时间  
    
* time_appconnect：SSL/SSH 等上层协议建立连接的时间
    
* time_redirect： 从开始到最后一个请求事务的时间  
    
* time_pretransfer：从请求开始到响应开始传输的时间  
    
* time_starttransfer： 从请求开始到第一个字节将要传输的时间  
    
* time_total：这次请求花费的全部时间

**示例**
```
curl -w "%{time_namelookup}\n%{time_connect}\n%{time_pretransfer}\n%{time_starttransfer}\n%{time_total}" -o /dev/null -s -L https://www.baidu.com
5.121
5.154
5.350
5.384
5.384
```
我这里是DNS解析慢，查询了可能的DNS解析慢的原因：

`
CentOS 6中的DNS解析器对于ipv4和ipv6都使用同一个socket接口，在同时发出ipv4和ipv6解析请求后，只会收到一个ipv4的解析响应，此时socket将一处于“等待”模式，等待ipv6的解析响应，故导致解析缓慢；添加single-request-reopen后就可以重新打开一个新的socket接收ipv6的解析响应，而不影响ipv4的解析响应
`
## 解决办法
在/etc/resolv.conf配置下第一行增加如下参数：
options timeout:1 attempts:1 rotate single-request-reopen






