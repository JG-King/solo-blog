title: fastjson只序列化需要的属性
date: '2019-10-30 19:22:49'
updated: '2019-10-30 19:22:49'
tags: [java]
permalink: /articles/2019/10/30/1572434569879.html
---
![](https://img.hacpai.com/bing/20181019.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
SimplePropertyPreFilter filter = new SimplePropertyPreFilter(SysUserDetails.class,"uId","uPhone","username","uSex","uType","uStatus");

JSON.toJSONString(sysUser,filter)

```
