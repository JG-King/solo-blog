title: 《12 | 多线程之锁优化(上):深入了解Synchronized同步锁的优化方法》笔记
date: '2019-11-21 22:08:57'
updated: '2019-11-21 22:39:17'
tags: [java性能调优实战]
permalink: /articles/2019/11/21/1574345337053.html
---
![](https://img.hacpai.com/bing/20180412.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

[原文](https://time.geekbang.org/column/article/101244)

## Synchronized的实现
Synchronized是JVM实现的一种内置锁，锁的获取和释放由JVM隐式实现。Synchronized是基于底层操作系统的Mutex Lock实现的，每次获取和释放锁操作都会带来用户态和内河态的切换，增加系统性能开销。

## Synchronized同步锁的实现原理
### 修饰方法
Synchronized修饰同步方法时，JVM使用ACC_SYNCHRONIZED访问标志来区分一个方法是否是同步方法。如果设置了该标志，执行线程将先持有Monitor对象，然后再执行方法，方法在执行期间，其他线程无法再获取Monitor对象，当法法执行完成后，再释放该Monitor对象。

### 修饰方法块
Synchronized在修饰同步代码块时，由monitorenter和monitorexit指令来实现同步的。进入monitorenter指令，线程持有Monitor对象，退出monitorenter指令，线程释放该Monitor对象。

### 实现原理
JVM中的同步是基于进入和退出管程(Monitor)对象实现的。每个对象实例都会有一个Monitor,Monitor可以和对象一起创建和销毁。

## 锁升级优化
* 偏向锁
* 轻量级锁
* 自旋锁与重量级锁
* 动态编译实现锁消除、锁粗化
* 减小锁粒度
![2e912fc6de6faeb1713a10959e5f1e99.png](https://img.hacpai.com/file/2019/11/2e912fc6de6faeb1713a10959e5f1e99-bcff67ee.png)



