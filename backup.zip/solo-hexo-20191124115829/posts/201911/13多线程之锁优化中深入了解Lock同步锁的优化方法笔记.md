title: 《13 | 多线程之锁优化(中):深入了解Lock同步锁的优化方法》笔记
date: '2019-11-23 00:08:10'
updated: '2019-11-23 00:08:10'
tags: [java性能调优实战]
permalink: /articles/2019/11/23/1574438890762.html
---
[原文](https://time.geekbang.org/column/article/101651)

## Lock同步锁
Lock同步锁需要显示获取和释放锁。Lock锁的基本实现是通过乐观锁来实现的,但由于Lock锁也会在阻塞时被挂起，因此它依然属于悲观锁

### Synchronized和Lock的特点
![8ec55dc637830f728e505c673fefde3d.jpg](https://img.hacpai.com/file/2019/11/8ec55dc637830f728e505c673fefde3d-a22b0e5e.jpg)

#### 性能方面
在并发量不高、竞争不激烈的情况下，Synchronized锁由于具有分级锁的优势，性能和Lock锁差不多。在高负载、高并发的情况下，Synchronized同步锁由于竞争激烈会升级到重量级锁，性能没有Lock锁稳定。

## 实现原理
Lock是一个接口类，常用的实现类有ReentrantLock,ReentrantReadWriteLock(RRW),它们都是依赖AbstractQueuedSynchronizer(AQS)类实现的。
AQS类结构中含有一个基于链表实现的等待队列(CLH队列)，用于存储所有阻塞的线程。AQS中还有一个state变量，该变量对ReentrantLock来说表示加锁状态。队列的操作通过CAS实现。
![222196b8c410ff4ffca7131faa19d833.jpg](https://img.hacpai.com/file/2019/11/222196b8c410ff4ffca7131faa19d833-d50967ca.jpg)

## 锁分离优化Lock同步锁

### 读写锁ReentrantReadWriteLock
![1bba37b281d83cdf0c51095f473001d1.jpg](https://img.hacpai.com/file/2019/11/1bba37b281d83cdf0c51095f473001d1-20f8ed76.jpg)

### StampedLock
StampedLock控制锁有三种模式写、悲观读、乐观读。
StampedLock不支持重入、条件变量。








